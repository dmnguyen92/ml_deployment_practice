# ml_deployment_practice
A practice project to deploy ML model
